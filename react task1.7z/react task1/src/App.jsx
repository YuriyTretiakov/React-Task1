import { Route, Routes } from 'react-router-dom'
import Main from './routes/Main/Main'
import './App.css'

export default function App() {
    return (
      <Main/>
    //  <Routes>
    //    <Route path='/' element={<Main />}/>
    //  </Routes>
  )
}


